Project Name: IYF programming timetable

Description:
This project displays a preview of my weekly timetable on a webpage. It includes an image of the timetable and is styled using an external CSS file.

Accessibility Considerations:
- All images have `alt` attributes to provide descriptions for users with screen readers.
- The page is designed with a high contrast for better readability.
- The site is responsive and adjusts to various screen sizes.

Created by: [TEDDY AYODI]
